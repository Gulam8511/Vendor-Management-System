package com.vms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VendorManagementSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
