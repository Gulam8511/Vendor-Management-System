package com.vms.entity;

import java.util.Date;
import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder

@Document(collection = "vendors")
public class Vendor {

	@Id
    private long vendorId; // Unique vendor ID

    @Field("vendorName")
    private String vendorName; // Name of the vendor

    @Field("category")
    private String category; // Category of vendor

    @Field("address")
    private String address; // Address of the vendor

    @Field("contactPerson")
    private String contactPerson; // Contact person

    @Field("phoneNumber")
    private String phoneNumber; // Phone number

    @Field("email")
    private String email; // Email address

    @Field("registrationDate")
    private Date registrationDate; // Vendor registration date

    @Field("status")
    private String status; // Vendor status (Active, Inactive)

    @Field("performanceScore")
    private int performanceScore; // Vendor's performance score

    @Field("documents")
    private List<FileMetaData>  fileMetaData; // List of document IDs (from GridFS)

    @Field("bankAccountDetails")
    private BankAccountDetails bankAccountDetails; // Embedded Bank Account Details

    @Field("vendorType")
    private String vendorType; // Type of vendor (e.g., Manufacturer)

    @Field("country")
    private String country; // Country of operation

    @Field("paymentTerms")
    private String paymentTerms; // Payment terms (e.g., Net 30 days)
    
    @Field("createdBy")
    private long createdBy; 
}
