package com.vms.entity;

import org.springframework.data.mongodb.core.mapping.Field;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class BankAccountDetails {

	 	@Field("accountNumber")
	    private String accountNumber; // Bank account number
	    
	    @Field("bankName")
	    private String bankName;       // Name of the bank
	    
	    @Field("ifscCode")
	    private String ifscCode;  
}
