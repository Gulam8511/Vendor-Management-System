package com.vms.entity;

import java.util.Date;
import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder

@Document(collection = "contracts")
public class Contract {

	 	@Id
	    private long contractId; 

	    private long vendorId; 

	    private String contractName; 

	    private String contractDescription;

	    private Date startDate;

	    private Date endDate; 

	    private String status; 

	    private String paymentTerms; 

	    private List<FileMetaData> fileMetaData; 

	    private Date createdAt; 

	    private long createdBy; 

	    private Date updatedAt; 
	    private Vendor vendor;

	    private long updatedBy; 
	    
	    private Date acceptedAt;
	    private Date rejectedAt;
	    private String rejectionReason; 
}
