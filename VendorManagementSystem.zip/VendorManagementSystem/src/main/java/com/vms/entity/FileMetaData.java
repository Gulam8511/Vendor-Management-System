package com.vms.entity;

import org.springframework.data.mongodb.core.mapping.Field;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class FileMetaData {

	@Field("fileID")
	private String fileID; 
	@Field("fileName")
    private String fileName;
	@Field("fileType")
    private String fileType;
}
