package com.vms.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.vms.entity.Contract;
import com.vms.entity.User;
import com.vms.entity.Vendor;
import com.vms.repository.VendorRepository;
import com.vms.security.JwtHelper;
import com.vms.services.ContractService;
import com.vms.services.UserService;

import jakarta.servlet.http.HttpServletRequest;

@RestController
@RequestMapping("/contracts")
public class ContractController {
	
	 @Autowired
	 private ContractService contractService;
	 
	 @Autowired
	 private JwtHelper jwtHelper;
	 
	 @Autowired
	 private UserService userService;
	 @Autowired
	 private VendorRepository vendorRepository;
	
	 @PostMapping
     public ResponseEntity<String> createContract(
             @RequestParam("contracts") String contractJson, 
             @RequestParam(required = false, name ="files") MultipartFile[] files,HttpServletRequest request) { 
 		 
 		String requestHeader = request.getHeader("Authorization");

        String userName = null;
        String token = null;
        if (requestHeader != null && requestHeader.startsWith("Bearer")) 
        {
        
            token = requestHeader.substring(7);
        }
		 userName = jwtHelper.getUsernameFromToken(token);
		 User user = userService.loadUserByUsername(userName);
 		 
         ObjectMapper objectMapper = new ObjectMapper();
         Contract contract;
         try {
        	 contract = objectMapper.readValue(contractJson, Contract.class);
        	 contract.setCreatedBy(user.getId());
        	 contract.setCreatedAt(new Date());
        	 Vendor vendor = vendorRepository.findById(contract.getVendorId()).get();
        	 if(vendor != null)
        	 {
        		 contract.setVendor(vendor);
        	 }
         } catch (IOException e) {
             return new ResponseEntity<>("Error parsing vendor data: " + e.getMessage(), HttpStatus.BAD_REQUEST);
         }

         try {
             contractService.createContractWithFiles(contract, files);
         } catch (Exception e) {
             return new ResponseEntity<>("Error creating vendor: " + e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
         }

         return new ResponseEntity<>("Vendor created successfully!", HttpStatus.OK);
     }
	 
	 @PutMapping("/{contractId}")
     public ResponseEntity<String> updateContract(
             @RequestParam("contracts") String contractJson, // Get the vendor JSON string
             @RequestParam(required = false,name = "files") MultipartFile[] files,@PathVariable long contractId,HttpServletRequest request) { // Get the files

 		 
 		String requestHeader = request.getHeader("Authorization");

        String userName = null;
        String token = null;
        if (requestHeader != null && requestHeader.startsWith("Bearer")) 
        {
        
            token = requestHeader.substring(7);
        }
		 userName = jwtHelper.getUsernameFromToken(token);
		 User user = userService.loadUserByUsername(userName);
         ObjectMapper objectMapper = new ObjectMapper();
         Contract contract;
         try {
             // Convert JSON string to Vendor object
        	 contract = objectMapper.readValue(contractJson, Contract.class);
        	 contract.setCreatedBy(user.getId());
        	 contract.setCreatedAt(new Date());
        	 contract.setUpdatedBy(user.getId());
        	 contract.setUpdatedAt(new Date());
        	 Vendor vendor = vendorRepository.findById(contract.getVendorId()).get();
        	 if(vendor != null)
        	 {
        		 contract.setVendor(vendor);
        	 }
         } catch (IOException e) {
             return new ResponseEntity<>("Error parsing vendor data: " + e.getMessage(), HttpStatus.BAD_REQUEST);
         }

         try {
             // Call the service to save vendor and files
             contractService .updateContractWithFiles(contract, files,contractId);
         } catch (Exception e) {
             return new ResponseEntity<>("Error creating vendor: " + e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
         }

         return new ResponseEntity<>("Vendor created successfully!", HttpStatus.OK);
     }
 	 
	 
	 @GetMapping
 	 public ResponseEntity<List<Contract>> getAllContract(HttpServletRequest request)
 	 {
 		String requestHeader = request.getHeader("Authorization");

        String userName = null;
        String token = null;
        if (requestHeader != null && requestHeader.startsWith("Bearer")) 
        {
        
            token = requestHeader.substring(7);
        }
		 userName = jwtHelper.getUsernameFromToken(token);
		 User user = userService.loadUserByUsername(userName);
		 List<Contract> contractList =  new ArrayList<>();
		 if(user.getRole().equals("ADMIN"))
		 {
			 contractList = contractService.getAllContracts(user.getId());
		 }
		 else if(user.getRole().equals("SUPERADMIN"))
		 {
			 contractList = contractService.getAllContracts();
		 }
		 else if(user != null && user.getRole().equals("VENDOR")) {
			 contractList = contractService.getAllContractsByVendor(user.getVendorId());
		 }
		 
 		 return ResponseEntity.status(HttpStatus.OK).body(contractList);
 	 }
	 
	 @DeleteMapping("/{contractId}")
     public ResponseEntity<String> deleteContract(@PathVariable long contractId) {
         try {
             contractService .deleteContract(contractId);
             return ResponseEntity.ok("contract deleted successfully!");
         } catch (Exception e) {
             return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error deleting contract: " + e.getMessage());
         }
     }
	 
	 @PostMapping("/{contractId}/accept")
	    public String acceptContract(@PathVariable long contractId,@RequestBody Contract contract, HttpServletRequest request) {

	       
	        return contractService.acceptContract(contractId, contract);
	    }
	 
	 
 	 

}
