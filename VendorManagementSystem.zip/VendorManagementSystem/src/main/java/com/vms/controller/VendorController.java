package com.vms.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.mongodb.client.gridfs.model.GridFSFile;
import com.vms.entity.User;
import com.vms.entity.Vendor;
import com.vms.security.JwtHelper;
import com.vms.services.UserService;
import com.vms.services.VendorService;

import jakarta.servlet.http.HttpServletRequest;

@RestController
@RequestMapping("/vendor")
public class VendorController {

	 	@Autowired
	    private VendorService vendorService;
	 	
	 	@Autowired
	 	private JwtHelper jwtHelper;
	 	
	 	@Autowired
	 	private UserService userService;
	 	
	 	@Autowired
	 	private PasswordEncoder passwordEncoder;

	 	 @PostMapping
	     public ResponseEntity<String> createVendor(
	             @RequestParam("vendors") String vendorJson, 
	             @RequestParam(required = false, name ="files") MultipartFile[] files,HttpServletRequest request) { 
	 		 
	 		String requestHeader = request.getHeader("Authorization");

	        String userName = null;
	        String token = null;
	        if (requestHeader != null && requestHeader.startsWith("Bearer")) 
	        {
	        
	            token = requestHeader.substring(7);
	        }
			 userName = jwtHelper.getUsernameFromToken(token);
			 User user = userService.loadUserByUsername(userName);
	 		 
	         ObjectMapper objectMapper = new ObjectMapper();
	         Vendor vendor;
	         try {
	             vendor = objectMapper.readValue(vendorJson, Vendor.class);
	             vendor.setCreatedBy(user.getId());
	         } catch (IOException e) {
	             return new ResponseEntity<>("Error parsing vendor data: " + e.getMessage(), HttpStatus.BAD_REQUEST);
	         }

	         try {
	             vendorService.createVendorWithFiles(vendor, files);
	         } catch (Exception e) {
	             return new ResponseEntity<>("Error creating vendor: " + e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
	         }

	         return new ResponseEntity<>("Vendor created successfully!", HttpStatus.OK);
	     }
	 	 
	 	@PutMapping("/{vendorId}")
	     public ResponseEntity<String> updateVendor(
	             @RequestParam("vendors") String vendorJson, // Get the vendor JSON string
	             @RequestParam(required = false,name = "files") MultipartFile[] files,@PathVariable long vendorId,HttpServletRequest request) { // Get the files

	 		 
	 		String requestHeader = request.getHeader("Authorization");

	        String userName = null;
	        String token = null;
	        if (requestHeader != null && requestHeader.startsWith("Bearer")) 
	        {
	        
	            token = requestHeader.substring(7);
	        }
			 userName = jwtHelper.getUsernameFromToken(token);
			 User user = userService.loadUserByUsername(userName);
	         ObjectMapper objectMapper = new ObjectMapper();
	         Vendor vendor;
	         try {
	             // Convert JSON string to Vendor object
	             vendor = objectMapper.readValue(vendorJson, Vendor.class);
	             vendor.setCreatedBy(user.getId());
	         } catch (IOException e) {
	             return new ResponseEntity<>("Error parsing vendor data: " + e.getMessage(), HttpStatus.BAD_REQUEST);
	         }

	         try {
	             // Call the service to save vendor and files
	             vendorService.updateVendorWithFiles(vendor, files,vendorId);
	         } catch (Exception e) {
	             return new ResponseEntity<>("Error creating vendor: " + e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
	         }

	         return new ResponseEntity<>("Vendor created successfully!", HttpStatus.OK);
	     }
	 	 
	 	 @GetMapping
	 	 public ResponseEntity<List<Vendor>> getAllVendors(HttpServletRequest request)
	 	 {
	 		String requestHeader = request.getHeader("Authorization");

	        String userName = null;
	        String token = null;
	        if (requestHeader != null && requestHeader.startsWith("Bearer")) 
	        {
	        
	            token = requestHeader.substring(7);
	        }
			 userName = jwtHelper.getUsernameFromToken(token);
			 User user = userService.loadUserByUsername(userName);
			 List<Vendor> vendorList = new ArrayList<>();
			 if(user.getRole().equals("ADMIN"))
			 {
				 vendorList = vendorService.getAllVendors(user.getId());
			 }
			 else if(user.getRole().equals("SUPERADMIN"))
			 {
				 vendorList = vendorService.getAllVendors();
			 }
	 		 return ResponseEntity.status(HttpStatus.OK).body(vendorList);
	 	 }
	 	 @DeleteMapping("/{vendorId}")
	     public ResponseEntity<String> deleteVendor(@PathVariable long vendorId) {
	         try {
	             vendorService.deleteVendor(vendorId);
	             return ResponseEntity.ok("Vendor deleted successfully!");
	         } catch (Exception e) {
	             return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error deleting vendor: " + e.getMessage());
	         }
	     }
	 	 
	 	@GetMapping("file/{fileId}")
	    public ResponseEntity<?> downloadFile(@PathVariable String fileId) {
	        try {
	            GridFSFile file = vendorService.getFileById(fileId);
	            if (file == null) {
	                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("File not found.");
	            }
	            return ResponseEntity.ok()
	                .contentType(MediaType.parseMediaType(file.getMetadata().getString("_contentType")))
	                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + file.getFilename() + "\"")
	                .body(vendorService.getFileResource(file));
	        } catch (Exception e) {
	            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error while downloading file: " + e.getMessage());
	        }
	    }
	 	 
}
