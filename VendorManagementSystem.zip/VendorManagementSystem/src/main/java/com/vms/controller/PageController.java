package com.vms.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ser.std.UUIDSerializer;
import com.vms.entity.User;
import com.vms.entity.Vendor;
import com.vms.repository.VendorRepository;
import com.vms.security.JwtHelper;
import com.vms.services.ContractService;
import com.vms.services.UserService;
import com.vms.services.VendorService;

import jakarta.servlet.http.HttpServletRequest;

@Controller
public class PageController {

	@Autowired
	private JwtHelper jwtHelper;
	
	@Autowired
	private UserService userService;
	
	@Autowired
	private UserDetailsService userDetailsService;

	@Autowired
	private VendorRepository vendorRepository;
	@Autowired
	private ContractService contractService;
	@Autowired
	private VendorService vendorService;
	
	@GetMapping("/login")
	public String login()
	{
		return "login";
	}
	@GetMapping("/register")
	public String register()
	{
		return "register";
	}
	
	@GetMapping("/dashboard")
	public String showDashboard(@RequestParam("Authorization") String token,Model model,HttpServletRequest request) throws IOException
	{
		String decodedToken = new String(Base64.getDecoder().decode(token));
		
		System.out.println("dashboard:::::token :: "+decodedToken);
		String userName = jwtHelper.getUsernameFromToken(decodedToken);
		System.out.println("userName::::::"+userName);
		User user = userService.loadUserByUsername(userName);
		boolean validateToken =false;
		UserDetails userDetails = userDetailsService.loadUserByUsername(userName);
		validateToken = jwtHelper.validateToken(decodedToken, userDetails);
		if(validateToken)
		{
			System.out.println("token validated");
			String returnRoleWise="";
		    returnRoleWise = user.getRole().equals("ADMIN") ? "Admin Dashboard" : user.getRole().equals("SUPERADMIN") ? "Super Admin Dashboard" : "";
		 	model.addAttribute("userName",userName); 
		 	model.addAttribute("pageHeading", returnRoleWise);
		 	model.addAttribute("role", user.getRole());
		 	model.addAttribute("title", "VMS | Dashboard");
		 	if(user.getRole().equals("ADMIN")) {
		 		Long contractCount =0l;
		 		contractCount = contractService.getContractCountByCreatedBy(user.getId());
		 		model.addAttribute("contractCount",contractCount);
		 		long vendorCount =0;
		 		vendorCount = vendorService.getVendorCountByCreatedBy(user.getId());
		 		model.addAttribute("vendorCount", vendorCount);
		 		
		 		Map<String, Long> contractByUserStatus = contractService.countContractsByStatusByUser(user.getId());
		 		ObjectMapper objectMapper = new ObjectMapper();
		        String contractByUserStatusJson = objectMapper.writeValueAsString(contractByUserStatus);
		        model.addAttribute("contractByUserStatus", contractByUserStatusJson);
		        
		        Map<String, Long> vendorByUserStatus = vendorService.countVendorsByStatusByUser(user.getId());
		 		ObjectMapper objectMapper1 = new ObjectMapper();
		        String vendorByUserStatusJson = objectMapper1.writeValueAsString(vendorByUserStatus);
		        model.addAttribute("vendorByUserStatus", vendorByUserStatusJson);
		        
		        Map<String, Long> contractByVendor = contractService.countVendorsByContractsByCreatedBy(user.getId());
		 		ObjectMapper objectMapper2 = new ObjectMapper();
		        String contractByVendorJson = objectMapper2.writeValueAsString(contractByVendor);
		        model.addAttribute("contractByVendor", contractByVendorJson);
		        
		 		return "adminDashboard";
		 	}else if(user.getRole().equals("SUPERADMIN")) {
		 		long contractCount =0;
		 		contractCount = contractService.getContractCount();
		 		model.addAttribute("contractCount", contractCount);
		 		long vendorCount = 0;
		 		vendorCount = vendorService.getVendorCount();
		 		model.addAttribute("vendorCount", vendorCount);

		 		Map<String, Long> contractByStatus = contractService.getContractsCountByStatus();
		 		ObjectMapper objectMapper = new ObjectMapper();
		        String contractByStatusJson = objectMapper.writeValueAsString(contractByStatus);
		        model.addAttribute("contractByStatus", contractByStatusJson);
		        
		        Map<String, Long> vendorByStatus = vendorService.getVendorCountByStatus();
		 		ObjectMapper objectMapper1 = new ObjectMapper();
		        String vendorByStatusJson = objectMapper1.writeValueAsString(vendorByStatus);
		        model.addAttribute("vendorByStatus", vendorByStatusJson);
		        
		        Map<String, Long> contractByVendor = contractService.getVendorContractCounts();
		 		ObjectMapper objectMapper2 = new ObjectMapper();
		        String contractByVendorJson = objectMapper2.writeValueAsString(contractByVendor);
		        model.addAttribute("contractByVendor", contractByVendorJson);
		 		
		 		return "superAdminDashboard";
		 	}else {
		 		
		 		long contractCount =0;
		 		contractCount = contractService.getContractCountByVendorId(user.getVendorId());
		 		model.addAttribute("contractCount", contractCount);
		 		
		 		Map<String, Long> contractStatusByVendor = contractService.countContractsByStatusByVendorId(user.getVendorId());
		 		ObjectMapper objectMapper = new ObjectMapper();
		        String contractStatusByVendorJson = objectMapper.writeValueAsString(contractStatusByVendor);
		        model.addAttribute("contractStatusByVendor", contractStatusByVendorJson);
		 		
		 		return "vendorDashboard";
		 	}
		 	
		}
		
		return "redirect:/login";
	}
	@GetMapping("/vendors")
	public String vendorList(@RequestParam("Authorization") String token,Model model)
	{

		String decodedToken = new String(Base64.getDecoder().decode(token));
		String userName = jwtHelper.getUsernameFromToken(decodedToken);
		User user = userService.loadUserByUsername(userName);
		boolean validateToken =false;
		UserDetails userDetails = userDetailsService.loadUserByUsername(userName);
		validateToken = jwtHelper.validateToken(decodedToken, userDetails);
		if(validateToken)
		{
			String returnRoleWise="";
		    returnRoleWise = user.getRole().equals("ADMIN") ? "Admin Dashboard" : user.getRole().equals("SUPERADMIN") ? "Super Admin Dashboard" : "";
		 	model.addAttribute("userName",userName); 
		 	model.addAttribute("role", user.getRole());
		 	model.addAttribute("pageHeading", returnRoleWise);
		 	model.addAttribute("title", "VMS | Venodr List");
		}
		return "vendorList";
	}
	
	@GetMapping("/contract")
	public String contractList(@RequestParam("Authorization") String token,Model model)
	{

		String decodedToken = new String(Base64.getDecoder().decode(token));
		String userName = jwtHelper.getUsernameFromToken(decodedToken);
		User user = userService.loadUserByUsername(userName);
		boolean validateToken =false;
		UserDetails userDetails = userDetailsService.loadUserByUsername(userName);
		validateToken = jwtHelper.validateToken(decodedToken, userDetails);
		if(validateToken)
		{
			List<Vendor> vendorList = new ArrayList<>();
			if(user.getRole().equals("ADMIN"))
			{
				vendorList = vendorRepository.findVendorsByUser(user.getId());
			}
			else if(user.getRole().equals("SUPERADMIN"))
			{
				vendorList = vendorRepository.findAll();
			}
			
			model.addAttribute("vendorList", vendorList);
			String returnRoleWise="";
		    returnRoleWise = user.getRole().equals("ADMIN") ? "Admin Dashboard" : user.getRole().equals("SUPERADMIN") ? "Super Admin Dashboard" : "";
		 	model.addAttribute("userName",userName); 
		 	model.addAttribute("role", user.getRole());
		 	model.addAttribute("pageHeading", returnRoleWise);
		 	model.addAttribute("title", "VMS | Contract List");
		}
		return "contractList";
	}
	
}
