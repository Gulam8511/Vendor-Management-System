package com.vms.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.vms.entity.User;
import com.vms.repository.UserRepository;

@Service
public class UserService {

	@Autowired
	private UserRepository repository;
	
	
	public User registerUser(User user)
	{
		User lastUser = null;
		lastUser = repository.findTopByOrderByIdDesc();
		long lastUserId = 1;
		if(lastUser != null){
			lastUserId = lastUser.getId()+1;
		}
		System.out.println("userID="+lastUserId);
		user.setId(lastUserId);
		return repository.save(user);
	}
	public User loadUserByUsername(String userName)
	{
		return repository.loadUserByUsername(userName);
	}
}
