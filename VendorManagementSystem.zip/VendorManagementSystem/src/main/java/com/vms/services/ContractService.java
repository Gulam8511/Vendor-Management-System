package com.vms.services;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.bson.types.ObjectId;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.gridfs.GridFsOperations;
import org.springframework.data.mongodb.gridfs.GridFsTemplate;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.vms.entity.Contract;
import com.vms.entity.FileMetaData;
import com.vms.entity.Vendor;
import com.vms.repository.ContractCustomRepository;
import com.vms.repository.ContractRepository;
import com.vms.repository.VendorRepository;

@Service
public class ContractService {
	
	
	
		@Autowired
	    private GridFsTemplate gridFsTemplate;
	 
	    @Autowired
	    private GridFsOperations gridFsOperations;
	    @Autowired
	    private ContractRepository contractRepository;
	    @Autowired
	    private ContractCustomRepository customRepository;
	    
	public void createContractWithFiles(Contract contract, MultipartFile[] files) throws IOException {
        List<FileMetaData> fileMetaDatas = new ArrayList<>();

        // Save files to GridFS and store the IDs
        if(files != null)
        {
	        for (MultipartFile file : files) {
	            ObjectId fileId = gridFsTemplate.store(file.getInputStream(), file.getOriginalFilename(), file.getContentType());
	            FileMetaData fileMetadata = new FileMetaData();
	            fileMetadata.setFileID(fileId.toString());
	            fileMetadata.setFileName(file.getOriginalFilename());
	            fileMetadata.setFileType(file.getContentType());
	           

	            // Add the metadata to the list
	            fileMetaDatas.add(fileMetadata);
	        }

	        contract.setFileMetaData(fileMetaDatas);// Set the file IDs in the vendor object
        }
        // Here you can add logic to save the vendor object in your database
        Contract lastContract= null;
        lastContract = contractRepository.findTopByOrderByContractIdDesc();
		long lastContractId = 1;
		if(lastContract != null){
			lastContractId =lastContract.getContractId()+1;
		}
		contract.setContractId(lastContractId);
        contractRepository.save(contract);
 
	}
	
	 public void updateContractWithFiles(Contract contract, MultipartFile[] files,long contractId) throws IOException {
	        List<FileMetaData> fileMetaDatas = new ArrayList<>();

	        System.out.println("fileID="+contract.getFileMetaData().get(0).getFileID());
	        if(files != null) {
	        deleteFile(contract.getFileMetaData().get(0).getFileID());
	        }
	        
	        // Save files to GridFS and store the IDs
	        if(files != null)
	        {	
		        for (MultipartFile file : files) {
		            ObjectId fileId = gridFsTemplate.store(file.getInputStream(), file.getOriginalFilename(), file.getContentType());
		            FileMetaData fileMetadata = new FileMetaData();
		            fileMetadata.setFileID(fileId.toString());
		            fileMetadata.setFileName(file.getOriginalFilename());
		            fileMetadata.setFileType(file.getContentType());
		           
	
		            // Add the metadata to the list
		            fileMetaDatas.add(fileMetadata);
		        }
	
		        contract.setFileMetaData(fileMetaDatas);// Set the file IDs in the vendor object
	        }
	       contractRepository .save(contract);
	    }
	
	public List<Contract> getAllContracts(long userId)
    {
    	return contractRepository .findContractsByUser(userId);
    }
	public List<Contract> getAllContractsByVendor(long userId)
    {
    	return contractRepository .findByVendorId(userId);
    }
	public void deleteContract(long contractId) {
        Contract contract = contractRepository .findById(contractId)
            .orElseThrow(() -> new RuntimeException("Vendor not found"));

        if (contract.getFileMetaData().get(0).getFileID() != null) {
            deleteFile(contract.getFileMetaData().get(0).getFileID());
        }

        contractRepository .deleteById(contractId);
    }
    
	 public void deleteFile(String fileId) {
	        gridFsTemplate.delete(Query.query(Criteria.where("_id").is(fileId)));
	 }
	 
	 public String acceptContract(long contractId, Contract contract) {
	        Optional<Contract> optionalContract = contractRepository.findById(contractId);
	        if (optionalContract.isPresent()) {
	            Contract existcontract = optionalContract.get();
	            // Check if the contract belongs to the vendor
	            if (existcontract.getVendorId() == contract.getVendorId()) {
	            	existcontract.setStatus(contract.getStatus());
	            	if(contract.getStatus().equals("Rejected")) {
	            		existcontract.setRejectionReason(contract.getRejectionReason());
	            		existcontract.setRejectedAt(new Date());
	            	}
	            	existcontract.setAcceptedAt(new Date());
	                contractRepository.save(existcontract);
	                return "Contract accepted successfully!";
	            }
	            return "Unauthorized: This contract does not belong to you.";
	        }
	        return "Contract not found!";
	    }

	  public long getContractCount() {
	        return contractRepository.count(); 
	    }
	  

	    public Map<String, Long> getContractsCountByStatus() {
	        return customRepository.countContractsByStatus();
	    }
	    
	    public Map<String, Long> getVendorContractCounts() {
	        return customRepository.countVendorsByContracts();
	    }

		public List<Contract> getAllContracts() {
			return contractRepository.findAll();
		}
		
		 public long getContractCountByCreatedBy(long userId) {
		        return customRepository.countByCreatedBy(userId);
		 }
		 
		 public Map<String, Long> countContractsByStatusByUser(long userId) {
		        return customRepository.countContractsByStatusByUser(userId);
		 }
		 
		 public Map<String, Long> countVendorsByContractsByCreatedBy(long userId) {
		        return customRepository.countVendorsByContractsByCreatedBy(userId);
		 }
		 
		 public long getContractCountByVendorId(long vendorId) {
		        return customRepository.countByVendorId(vendorId);
		 }
		 
		 public Map<String, Long> countContractsByStatusByVendorId(long vendorId) {
		        return customRepository.countContractsByStatusByVendorId(vendorId);
		 }
}
