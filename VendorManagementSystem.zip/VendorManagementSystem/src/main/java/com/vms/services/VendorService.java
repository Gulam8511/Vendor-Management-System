package com.vms.services;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Random;

import org.bson.types.ObjectId;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.gridfs.GridFsOperations;
import org.springframework.data.mongodb.gridfs.GridFsResource;
import org.springframework.data.mongodb.gridfs.GridFsTemplate;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.mongodb.client.gridfs.model.GridFSFile;
import com.vms.entity.FileMetaData;
import com.vms.entity.User;
import com.vms.entity.Vendor;
import com.vms.repository.VendorCustomRepository;
import com.vms.repository.VendorRepository;

@Service
public class VendorService {

	    @Autowired
	    private GridFsTemplate gridFsTemplate;

	    @Autowired
	    private VendorRepository vendorRepository;
	    @Autowired
	    private UserService userService;
	    @Autowired
	    private PasswordEncoder passwordEncoder;
	    @Autowired
	    private GridFsOperations gridFsOperations;
	    @Autowired
	    private VendorCustomRepository customRepository;

	    public void createVendorWithFiles(Vendor vendor, MultipartFile[] files) throws IOException {
	        List<FileMetaData> fileMetaDatas = new ArrayList<>();

	        // Save files to GridFS and store the IDs
	        if(files != null)
	        {
		        for (MultipartFile file : files) {
		            ObjectId fileId = gridFsTemplate.store(file.getInputStream(), file.getOriginalFilename(), file.getContentType());
		            FileMetaData fileMetadata = new FileMetaData();
		            fileMetadata.setFileID(fileId.toString());
		            fileMetadata.setFileName(file.getOriginalFilename());
		            fileMetadata.setFileType(file.getContentType());
		           
	
		            // Add the metadata to the list
		            fileMetaDatas.add(fileMetadata);
		        }
	
		        vendor.setFileMetaData(fileMetaDatas);// Set the file IDs in the vendor object
	        }
	        // Here you can add logic to save the vendor object in your database
	        Vendor lastVendor = null;
	        lastVendor = vendorRepository.findTopByOrderByVendorIdDesc();
			long lastVendorId = 1;
			if(lastVendor != null){
				lastVendorId =lastVendor.getVendorId()+1;
			}
			vendor.setVendorId(lastVendorId);
			vendor.setRegistrationDate(new Date());
			User vendorUser =  new User();
	       	 vendorUser.setUserName("vendor"+new Random().nextInt(30));
	       	 vendorUser.setPassword(passwordEncoder.encode("vendor123"));
	       	 vendorUser.setRole("VENDOR");
	       	 vendorUser.setVendorId(vendor.getVendorId());
	       	 userService.registerUser(vendorUser);
	        vendorRepository.save(vendor);
	    }
	    public void updateVendorWithFiles(Vendor vendor, MultipartFile[] files,long vendorId) throws IOException {
	        List<FileMetaData> fileMetaDatas = new ArrayList<>();

	        System.out.println("fileID="+vendor.getFileMetaData().get(0).getFileID());
	        if(files != null) {
	        deleteFile(vendor.getFileMetaData().get(0).getFileID());
	        }
	        
	        // Save files to GridFS and store the IDs
	        if(files != null)
	        {	
		        for (MultipartFile file : files) {
		            ObjectId fileId = gridFsTemplate.store(file.getInputStream(), file.getOriginalFilename(), file.getContentType());
		            FileMetaData fileMetadata = new FileMetaData();
		            fileMetadata.setFileID(fileId.toString());
		            fileMetadata.setFileName(file.getOriginalFilename());
		            fileMetadata.setFileType(file.getContentType());
		           
	
		            // Add the metadata to the list
		            fileMetaDatas.add(fileMetadata);
		        }
	
		        vendor.setFileMetaData(fileMetaDatas);// Set the file IDs in the vendor object
	        }
	       vendorRepository.save(vendor);
	    }
	    
	    public List<Vendor> getAllVendors(long userId)
	    {
	    	return vendorRepository.findVendorsByUser(userId);
	    }
	    
	    public void deleteVendor(long vendorId) {
	        // Fetch the vendor to get the file ID (if needed)
	        Vendor vendor = vendorRepository.findById(vendorId)
	            .orElseThrow(() -> new RuntimeException("Vendor not found"));

	        // Assuming vendor has a field called 'fileId' for the associated file
	        if (vendor.getFileMetaData().get(0).getFileID() != null) {
	            // Delete the file from GridFS
	            deleteFile(vendor.getFileMetaData().get(0).getFileID());
	        }

	        // Delete the vendor
	        vendorRepository.deleteById(vendorId);
	    }
	    
	    public void deleteFile(String fileId) {
	        gridFsTemplate.delete(Query.query(Criteria.where("_id").is(fileId)));
	    }
	    
	    public GridFSFile getFileById(String fileId) {
	        return gridFsTemplate.findOne(Query.query(Criteria.where("_id").is(fileId)));
	    }

	    public InputStreamResource getFileResource(GridFSFile file) throws IOException {
	        GridFsResource resource = gridFsOperations.getResource(file);
	        return new InputStreamResource(resource.getInputStream());
	    }
	    
	    public long getVendorCount()
	    {
	    	return vendorRepository.count();
	    }
	    
	    public Map<String, Long> getVendorCountByStatus() {
	        return customRepository.countVendorsByStatus();
	    }
		public List<Vendor> getAllVendors() {
			return vendorRepository.findAll();
		}
		
		public long getVendorCountByCreatedBy(long userId) 
		{
	        return customRepository.countByCreatedBy(userId);
		}
		
		public Map<String, Long> countVendorsByStatusByUser(long userId) 
		{
	        return customRepository.countVendorsByStatusByUser(userId);
	    }
}

