package com.vms.repository;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import com.vms.entity.Vendor;
@Repository
public interface VendorRepository extends MongoRepository<Vendor, Long> {
	Vendor findTopByOrderByVendorIdDesc(); 
	 @Query("{ 'createdBy': ?0 }")
	  List<Vendor> findVendorsByUser(long userId);
	 long count();
}
