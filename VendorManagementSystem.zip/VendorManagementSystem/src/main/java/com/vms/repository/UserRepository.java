package com.vms.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import com.vms.entity.User;
@Repository
public interface UserRepository extends MongoRepository<User, Long> {
	
	@Query("{ 'userName' : ?0 }")
	public User loadUserByUsername(String userName);
	
	 User findTopByOrderByIdDesc(); 
	
	
}
