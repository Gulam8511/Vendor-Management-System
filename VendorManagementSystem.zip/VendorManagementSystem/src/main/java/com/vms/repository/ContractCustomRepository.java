package com.vms.repository;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.aggregation.Aggregation;
import org.springframework.data.mongodb.core.aggregation.AggregationResults;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;

import com.vms.entity.Contract;
@Repository
public class ContractCustomRepository {

	 	@Autowired
	    private MongoTemplate mongoTemplate;

	    public Map<String, Long> countContractsByStatus() {
	    	Aggregation aggregation = Aggregation.newAggregation(
	                Aggregation.group("status").count().as("count")
	        );

	        AggregationResults<Map> result = mongoTemplate.aggregate(aggregation, "contracts", Map.class);

	        Map<String, Long> statusCountMap = new HashMap<>();
	        for (Map statusCount : result.getMappedResults()) {
	            String status = (String) statusCount.get("_id");
	            Object countObj = statusCount.get("count");

	            Long count = countObj instanceof Integer ? ((Integer) countObj).longValue() : (Long) countObj;

	            statusCountMap.put(status, count);
	        }

	        return statusCountMap;
	    }
	    
	    public Map<String, Long> countVendorsByContracts() {
	    	 Aggregation aggregation = Aggregation.newAggregation(
	    	            // Match stage to exclude contracts where vendorId is null
	    	            Aggregation.match(Criteria.where("vendorId").ne(null)),
	    	            Aggregation.lookup("vendors", "vendorId", "_id", "vendorDetails"),
	    	            Aggregation.unwind("vendorDetails"), // Unwind the joined vendor details
	    	            Aggregation.group("vendorDetails.vendorName").count().as("contractCount") // Group by vendor name and count contracts
	    	        );

	    	        AggregationResults<Map> result = mongoTemplate.aggregate(aggregation, "contracts", Map.class);

	    	        Map<String, Long> vendorContractCountMap = new HashMap<>();
	    	        for (Map vendorContractCount : result.getMappedResults()) {
	    	            String vendorName = (String) vendorContractCount.get("_id");
	    	            Object countObj = vendorContractCount.get("contractCount");
	    	            
	    	            // Handle possible null vendor names
	    	            if (vendorName != null) {
	    	                Long count = countObj instanceof Integer ? ((Integer) countObj).longValue() : (Long) countObj;
	    	                vendorContractCountMap.put(vendorName, count);
	    	            }
	    	        }

	    	        return vendorContractCountMap;
	       
	    }
	    
	    
	    public long countByCreatedBy(long userId) {
	        return mongoTemplate.count(Query.query(Criteria.where("createdBy").is(userId)), Contract.class);
	    }
	    
	    public Map<String, Long> countContractsByStatusByUser(long userId) {

	    	Aggregation aggregation = Aggregation.newAggregation(
	                Aggregation.match(Criteria.where("createdBy").is(userId)), // Match contracts created by the logged-in user
	                Aggregation.group("status").count().as("count") // Group by status and count
	        );

	        AggregationResults<Map> result = mongoTemplate.aggregate(aggregation, "contracts", Map.class);

	        Map<String, Long> statusCountMap = new HashMap<>();
	        for (Map statusCount : result.getMappedResults()) {
	            String status = (String) statusCount.get("_id");
	            Object countObj = statusCount.get("count");

	            Long count = countObj instanceof Integer ? ((Integer) countObj).longValue() : (Long) countObj;

	            statusCountMap.put(status, count);
	        }

	        return statusCountMap;
	    }
	    
	    public Map<String, Long> countVendorsByContractsByCreatedBy(long userId) {
	        Aggregation aggregation = Aggregation.newAggregation(
	                // Match stage to filter contracts based on createdBy
	                Aggregation.match(Criteria.where("createdBy").is(userId)), // Filter by createdBy
	                Aggregation.lookup("vendors", "vendorId", "_id", "vendorDetails"), // Join with vendors collection
	                Aggregation.unwind("vendorDetails"), // Unwind the joined vendor details
	                Aggregation.group("vendorDetails.vendorName") // Group by vendor name
	                    .count().as("contractCount") // Count contracts for each vendor
	        );

	        AggregationResults<Map> result = mongoTemplate.aggregate(aggregation, "contracts", Map.class);

	        Map<String, Long> vendorContractCountMap = new HashMap<>();
	        for (Map vendorContractCount : result.getMappedResults()) {
	            String vendorName = (String) vendorContractCount.get("_id");
	            Object countObj = vendorContractCount.get("contractCount");
	            
	            // Handle possible null vendor names
	            if (vendorName != null) {
	                Long count = countObj instanceof Integer ? ((Integer) countObj).longValue() : (Long) countObj;
	                vendorContractCountMap.put(vendorName, count);
	            }
	        }

	        return vendorContractCountMap;
	    }
	    
	    public long countByVendorId(long vendorId) {
	        return mongoTemplate.count(Query.query(Criteria.where("vendorId").is(vendorId)), Contract.class);
	    }
	    
	    public Map<String, Long> countContractsByStatusByVendorId(long vendorId) {

	    	Aggregation aggregation = Aggregation.newAggregation(
	                Aggregation.match(Criteria.where("vendorId").is(vendorId)), // Match contracts created by the logged-in user
	                Aggregation.group("status").count().as("count") // Group by status and count
	        );

	        AggregationResults<Map> result = mongoTemplate.aggregate(aggregation, "contracts", Map.class);

	        Map<String, Long> statusCountMap = new HashMap<>();
	        for (Map statusCount : result.getMappedResults()) {
	            String status = (String) statusCount.get("_id");
	            Object countObj = statusCount.get("count");

	            Long count = countObj instanceof Integer ? ((Integer) countObj).longValue() : (Long) countObj;

	            statusCountMap.put(status, count);
	        }

	        return statusCountMap;
	    }

}
