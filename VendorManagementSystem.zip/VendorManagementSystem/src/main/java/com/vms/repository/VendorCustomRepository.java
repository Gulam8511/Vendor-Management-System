package com.vms.repository;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.aggregation.Aggregation;
import org.springframework.data.mongodb.core.aggregation.AggregationResults;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;

import com.vms.entity.Contract;
import com.vms.entity.Vendor;

@Repository
public class VendorCustomRepository {

	@Autowired
	private MongoTemplate mongoTemplate;
	
	public Map<String, Long> countVendorsByStatus() {
    
		Aggregation aggregation = Aggregation.newAggregation(
            Aggregation.group("status").count().as("count") // Group by status and count vendors
        );

        AggregationResults<Map> result = mongoTemplate.aggregate(aggregation, "vendors", Map.class);

        Map<String, Long> statusCountMap = new HashMap<>();
        for (Map statusCount : result.getMappedResults()) {
            String status = (String) statusCount.get("_id");
            Object countObj = statusCount.get("count");

            // Convert count to Long
            Long count = countObj instanceof Integer ? ((Integer) countObj).longValue() : (Long) countObj;
            statusCountMap.put(status, count);
        }

        return statusCountMap;
    }
	
	public long countByCreatedBy(long userId) {
        return mongoTemplate.count(Query.query(Criteria.where("createdBy").is(userId)), Vendor.class);
    }
	
	 public Map<String, Long> countVendorsByStatusByUser(long userId) {

		 Aggregation aggregation = Aggregation.newAggregation(
	                Aggregation.match(Criteria.where("createdBy").is(userId)), // Match vendors created by the logged-in user
	                Aggregation.group("status").count().as("count") // Group by status and count
	        );

	        AggregationResults<Map> result = mongoTemplate.aggregate(aggregation, "vendors", Map.class);

	        Map<String, Long> statusCountMap = new HashMap<>();
	        for (Map statusCount : result.getMappedResults()) {
	            String status = (String) statusCount.get("_id");
	            Object countObj = statusCount.get("count");

	            // Convert count to Long
	            Long count = countObj instanceof Integer ? ((Integer) countObj).longValue() : (Long) countObj;
	            statusCountMap.put(status, count);
	        }

	        return statusCountMap;
	    }
}
