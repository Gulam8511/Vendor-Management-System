package com.vms.repository;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import com.vms.entity.Contract;
import com.vms.entity.Vendor;

@Repository
public interface ContractRepository extends MongoRepository<Contract, Long> {
	
	Contract findTopByOrderByContractIdDesc();
	 @Query("{ 'createdBy': ?0 }")
	  List<Contract> findContractsByUser(long userId);
	  List<Contract> findByVendorId(long vendorId);
	  long count(); 
	  @Query(value = "{ 'createdBy': ?0 }")
	  long countByCreatedBy(long userId);
}
